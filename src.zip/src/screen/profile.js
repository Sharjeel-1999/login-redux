import React from "react";
import { connect } from "react-redux";

function Profile(prop) {
  console.log(prop, "prop");
  return (
    <div>
        <h1>Profile</h1>
     <h3>{prop.email}</h3>
     <h3>{prop.password}</h3>
    </div>
  );
}



const mapReduxStateToProps = (state) => {
  return {
    email: state.email,
    password: state.password,
  };
};

const newApp = connect(mapReduxStateToProps)(Profile);

export default newApp;
