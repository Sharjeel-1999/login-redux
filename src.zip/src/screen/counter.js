import React from "react";
import { connect } from "react-redux";

function Counter(prop) {
  console.log(prop, "prop");
  return (
    <div>
      <h1>Counter</h1>
      <h1>{prop.counter}</h1>
      <button onClick={() => prop.dispatch({ type: "INCREMENT" })}>Add</button>
    </div>
  );
}

// const connectApp = connect() ///new function
// const newApp = connectApp(Counter) //new component

const mapReduxStateToProps = (state) => {
  return {
    counter: state.counter,
  };
};

const newApp = connect(mapReduxStateToProps)(Counter);

export default newApp;
