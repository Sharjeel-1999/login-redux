import React,{useState} from "react";
import { connect } from "react-redux";

function Login(prop) {
  console.log(prop, "prop");
const [state,setState]= useState({
    email:"",password:""
})
console.log(state,'state')
  return (
    <div>
      <h1>Login</h1>
    <input type="text" onChange={(val)=>setState({...state,email:val.target.value})} />
    <input type="text" onChange={(val)=>setState({...state,password:val.target.value})} />

    <button onClick={()=>prop.dispatch({type:"UPDATE_USERD_DATA",email:state.email
,pass:state.password})}>Login</button>
    </div>
  );
}





const newApp = connect()(Login);

export default newApp;
