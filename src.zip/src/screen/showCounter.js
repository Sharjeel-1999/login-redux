import React from "react";
import { connect } from "react-redux";



function ShowCounter(prop) {
    console.log(prop, "prop");
    return (
      <div>
        <h1>Show Counter</h1>
        <h1>{prop.counter}</h1>
        <button onClick={() => prop.dispatch({ type: "DECREMENT" })}>Substract</button>
      </div>
    );
  }


  const mapReduxStateToProps = (state) => {
    return {
      counter: state.counter,
    };
  };
  
  const newApp = connect(mapReduxStateToProps)(ShowCounter);
  
  export default newApp;
  