import "./App.css";
import Counter from './screen/counter'
import ShowCounter from './screen/showCounter'
import Login from './screen/login';
import Profile from './screen/profile'
import React from 'react'
import {Provider} from 'react-redux'
import store from './store/store'

function App() {
  return <Provider store={store}>
    {/* <Counter />
    <ShowCounter /> */}
    <Login />
    <Profile />
  </Provider>;
}

export default App;
