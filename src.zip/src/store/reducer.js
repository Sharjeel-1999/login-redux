const INITIAL_STATE = {
  counter: 0,
  email:"",
  userName:"",
  password:""
};

function reducer(state = INITIAL_STATE, action) {
  switch (action.type) {
    case "INCREMENT":
      return { ...state, counter: state.counter + 1 };
    case "DECREMENT":
      return { ...state, counter: state.counter - 1 };

      case "UPDATE_USERD_DATA":
          console.log(action,'action')
          return {...state,email:action.email,password:action.pass}
  }
  return state;
}

export default reducer;
